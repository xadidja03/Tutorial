public class Task3 {
    public static void main(String[] args) {
        int f,g,result;
        f=125;
        g=24;
        result=f+g;
        System.out.println(result);
        result=f-g;
        System.out.println(result);
        result=f*g;
        System.out.println(result);
        result=f/g;
        System.out.println(result);
        result=f%g;
        System.out.println(result);

    }
}
