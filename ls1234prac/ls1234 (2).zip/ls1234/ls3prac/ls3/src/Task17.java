import java.util.Scanner;

public class Task17 {
    public static void main(String[] args) {
        while (true) {

            Scanner scanner = new Scanner(System.in);
            System.out.print("eded daxil edin:");
            int eded = scanner.nextInt();
            if (eded > 100 | eded % 2 == 0) {
                System.out.println("Successful");
            } else {
                System.out.println("Unsuccessful");
            }
        }
    }
}
