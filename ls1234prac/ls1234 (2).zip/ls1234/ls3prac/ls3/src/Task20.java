import java.util.Scanner;

public class Task20 {
    public static void main(String[] args) {
        while (true) {

            Scanner scanner = new Scanner(System.in);
            System.out.print("eded daxil edin:");
            int eded = scanner.nextInt();
            if (eded > 50 | eded >= 0) {
                System.out.println(eded+10);
            } else {
                System.out.println("Invalid");
            }
        }
    }
}

