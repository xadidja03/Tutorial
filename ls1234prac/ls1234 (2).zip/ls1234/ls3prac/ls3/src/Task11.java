import java.util.Scanner;

public class Task11 {
    public static void main(String[] args) {
        while (true) {

            Scanner scanner = new Scanner(System.in);
            System.out.print("eded daxil edin:");
            int eded = scanner.nextInt();
            if (eded % 2 == 0) {
                System.out.println("Cut eded");
            } else {
                System.out.println("Tek eded");
            }
        }
    }
}