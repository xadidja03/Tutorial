import java.util.Scanner;

public class Task26 {
    public static void main(String[] args) {
        foo();
    }

    public static int foo() {
        Scanner input = new Scanner(System.in);
        System.out.println("ededi daxil edin:");
        int eded = input.nextInt();
        if (eded > 0) {
            System.out.println(1);
        } else if (eded == 0) {
            System.out.println(0);
        } else if (eded < 0) {
            System.out.println(-1);

        }return 1;
    }
}
