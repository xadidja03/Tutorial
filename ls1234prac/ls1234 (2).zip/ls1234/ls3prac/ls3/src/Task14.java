import java.util.Scanner;

public class Task14 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print(" 1 ci ededi daxil edin:");
        int eded1 = scanner.nextInt();
        System.out.print(" 2 ci ededi daxil edin:");
        double eded2 = scanner.nextDouble();
        var hasil = eded2 * eded1;
        System.out.println("ededlerin hasili:" + hasil);
        if (hasil > 100) {
            System.out.println("100-u kecdiniz!!");
        } else {
            System.out.println("100-u kecmediniz!");
        }
    }
    }