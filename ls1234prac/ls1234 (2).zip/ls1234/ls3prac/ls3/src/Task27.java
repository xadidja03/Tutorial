import java.util.Scanner;

public class Task27 {
    public static void main(String[] args) {
        value();
    }
    public static  boolean value(){
        Scanner scanner=new Scanner(System.in);
        int eded1=scanner.nextInt();
        int eded2=scanner.nextInt();
        int eded3=scanner.nextInt();
        int eded4=scanner.nextInt();
        if (eded1==eded2 & eded1== eded3| eded1== eded4& eded2== eded3| eded2== eded4& eded3== eded4){
            System.out.println(true);
        }else{
            System.out.println(false);
        }return false;
    }
}
