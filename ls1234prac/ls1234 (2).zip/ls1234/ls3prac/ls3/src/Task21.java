public class Task21 {
    public static void main(String[] args) {
        value(true);
    }
    public static  boolean value(boolean val){
        int a = 4; int b=3;
        if (val==true){
            System.out.println(a*b);
        }else {
            System.out.println(a+b);
        }return false;
    }
}
