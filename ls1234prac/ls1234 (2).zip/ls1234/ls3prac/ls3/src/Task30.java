import java.util.Scanner;

public class Task30 {
    public static void main(String[] args) {
        foo();
    }

    public static boolean foo() {
        Scanner input = new Scanner(System.in);
        System.out.println("string daxil edin:");
        String word1 = input.nextLine();
        System.out.println("string daxil edin:");
        String word2 = input.nextLine();
        if (word1.equals(word2)) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }
        return false;
    }
}