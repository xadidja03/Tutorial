public class Task18 {
    public static void main(String[] args) {
        value(true);
    }
    public static  boolean value(boolean val){
        if (val){
            System.out.println("This is true");
        }else{
            System.out.println("This is false");
        }return false;
    }
}
