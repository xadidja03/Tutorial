public class Task4 {
    public static void main(String[] args) {
        int onluq = 82;
        int sekizlik = onlukSekizlik(onluq);
        System.out.printf("%d (onluq) = %d (sekizlik)", onluq, sekizlik);
    }

    public static int onlukSekizlik(int onluq)
    {
        int sekizlikeded = 0, i = 1;

        while (onluq != 0)
        {
            sekizlikeded += (onluq % 8) * i;
            onluq /= 8;
            i *= 10;
        }

        return sekizlikeded;
    }
}
