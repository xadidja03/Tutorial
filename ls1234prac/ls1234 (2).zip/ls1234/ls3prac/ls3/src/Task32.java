import java.util.Scanner;

public class Task32 {
    public static void main(String[] args) {
        foo();
    }
    public static boolean foo() {
        Scanner input = new Scanner(System.in);
        System.out.println("1 ci sozu daxil edin:");
        String a = input.nextLine();
        System.out.println("2 ci sozu daxil edin:");
        String b = input.nextLine();
        System.out.println("3 cu sozu daxil edin:");
        String c = input.nextLine();
        if (a.contains(c)&& b.contains(c)){
            System.out.println(true);
        }else {
            System.out.println(false);
        }
        return false;
    }
}
