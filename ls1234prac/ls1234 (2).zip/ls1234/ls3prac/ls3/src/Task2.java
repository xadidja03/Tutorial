public class Task2 {
    static public void binaryDonustur(int eded){
        int binary[] = new int[40];
        int index = 0;
        while(eded > 0){
            binary[index++] = eded%2;
            eded = eded/2;
        }
        for(int i = index-1;i >= 0;i--){
            System.out.print(binary[i]);
        }
    }

    public static void main(String a[]){

        System.out.print("1234: ");
        binaryDonustur(1234);
        System.out.print("\n18: ");
        binaryDonustur(18);
        System.out.print("\n");
    }
}
