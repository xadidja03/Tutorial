public class Task5 {
    public static void main(String[] args) {
        int onluq = 82;
        int onaltiliq = onlukonaltiliq(onluq);
        System.out.printf("%d (onluq) = %d (onaltiliq)", onluq, onaltiliq);
    }

    public static int onlukonaltiliq(int onluq)
    {
        int onaltiliq = 0, i = 1;

        while (onluq != 0)
        {
            onaltiliq += (onluq % 16) * i;
            onluq /= 16;
            i *= 10;
        }

        return onaltiliq;
    }
}
