import java.util.Arrays;
import java.util.Scanner;

@SuppressWarnings("removal")
public class Main {
    public static void main(String[] args) {
        //task1
        String str = "Xedice";
        System.out.println(str.indexOf("i"));
        //task2
        var x = 30;
        var y = 59;
        x = x + y;
        y = x - y;
        x = x - y;
        System.out.println(x);
        System.out.println(y);

        //task3
        String str2 = "    1,e 6,e 0,e 9,e     ";
        String str1 = str2.trim() + " ";
        String[] strNew = str1.split(",e ");
        System.out.println(strNew);
        //task4
        String str3 = "1,2,3,4,5,6,7,8,9";
        System.out.println(Arrays.toString(str3.split(",")));

        //task5
        String username = "Khadija Madnayeva";
        String password = "xedice2010";
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the username: ");
        String name = scanner.nextLine();
        System.out.println("Enter the password: ");
        String password2 = scanner.nextLine();
        if ((username.equals(name)) && (password2.equals(password))) {
            System.out.println("Welcome " + name);

        } else {
            System.out.println("Invalid password");
        }



        //task6
        int a = 4;
        int b = 5;
        System.out.println(Math.max(a, b));
        double e=7.9999999999;
        double e2=9.99999998;
        System.out.println(Math.max(e,e2));

        //task7
        int x1 = 6;
        double y1 = x1;
        System.out.println(y1);

        //task8
        float a1 = 66;
        float b1 = 9;
        float z = a1 / b1;
        System.out.println(z);

        //task9
        byte a2 = 7;
        Byte b2 = new Byte(a2);
        int output = b2.intValue();
        System.out.println(output);
        //task10
        int k = 7;
        Integer integer = new Integer(k);
        double new_num = integer.doubleValue();
        System.out.println(new_num);
        //task11
        int l = 457825;
        System.out.println(l / 10);
        //task12
        int h = 234;
        int j = 45;
        int p = (h / 10) + (j / 10);
        System.out.println(p);
        //task13
        var c = 10;
        var d1=7;
        var c1 = c=d1;

        //task14
        String count = "45";
        System.out.println(Integer.valueOf(count));
        //task15
        short num=8;
        int num2=num;
        System.out.println(num2);

        //task16
        String a9 = "15";
        String a8 = "35";
        System.out.println(Integer.valueOf(a9) + Integer.valueOf(a8));

        //task17
        String words = "Hello World";
        String word = "Hello";
        if (word.length() < words.length()) {
            System.out.println(words);
        } else {
            System.out.println(word);
        }

        //task18
        String letter="Great Power";
        StringBuffer newStr=new StringBuffer(str1);

        for(int i = 0; i < str1.length(); i++) {
            if(Character.isLowerCase(str1.charAt(i))) {
                newStr.setCharAt(i, Character.toUpperCase(str1.charAt(i)));
            }
            else if(Character.isUpperCase(str1.charAt(i))) {
                newStr.setCharAt(i, Character.toLowerCase(str1.charAt(i)));
            }
        }
        System.out.println("String after case conversion : " + newStr);

    //task19
        String string = "   SALAM NECESEN ISLER NECE GEDIR?   ";
        System.out.println(string.trim());


        //task20
        System.out.println("Hello World"); // This is a comment
        /* The coding is amazing */
        System.out.println("This is Multi-line commends");
        /**
         *
         *We can use various tags to depict the parameter
         *or heading or author name
         *We can also use HTML tags
         *
         */


    }}