import java.util.Scanner;

public class Task15 {
    public static void main(String[] Strings) {

        Scanner input = new Scanner(System.in);

        System.out.print("Input a degree in Fahrengeyt: ");
        double fahrengeit = input.nextDouble();

        double  selsi =(( 5 *(fahrengeit - 32.0)) / 9.0);
        System.out.println(fahrengeit + " degree Fahrenheit is equal to " + selsi + " in Celsius");
    }
}
