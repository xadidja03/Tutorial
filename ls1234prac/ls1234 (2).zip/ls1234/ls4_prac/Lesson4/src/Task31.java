public class Task31 {
}
