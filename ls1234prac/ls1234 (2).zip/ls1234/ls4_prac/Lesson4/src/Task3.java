import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Ededi daxil edin:");
        int eded=scanner.nextInt();
        int i=1; int sum = 0; int digit;
        while (i<=eded){
            digit = eded % 10;
            sum = sum + digit;
            eded= eded/ 10;
        }
        System.out.println("Sum of Digits: "+sum);
    }
    }

