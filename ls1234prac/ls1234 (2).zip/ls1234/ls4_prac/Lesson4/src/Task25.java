public class Task25 {

    public static void main(String[] args) {
        int n=10;
        for (int i=1;i<=n;i++){
            System.out.println(i);

        }
    }
}