import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Ededi daxil edin : ");
        int eded= scanner.nextInt();
        int i=1;
        for(i = 1; i <= eded; i++)
        {
            if(i % 2 != 0)
            {
                System.out.print(i +"\t");
            }
        }

    }

}