import java.util.Scanner;

public class Task20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("1 ci ededi daxil edin: ");
        int a = in.nextInt();
        System.out.print("2 ci ededi daxil edin: ");
        int b = in.nextInt();
        System.out.println (a+b);
        System.out.println (a-b);
        System.out.println ( a*b);
        System.out.println ( (a+b)/2);
        System.out.println ( b-a);
        System.out.println ( Math.min(a,b));
        System.out.println ( Math.max(a,b));
    }
}
