import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("original");
        String string=scanner.nextLine();
        System.out.println("reversed");
        String rstring=scanner.nextLine();
        if (string.equals(rstring)){
            System.out.println(true);
        }else {
            System.out.println(false);
        }
    }
}
