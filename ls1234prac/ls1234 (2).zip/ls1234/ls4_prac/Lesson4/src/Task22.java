import java.util.Scanner;

public class Task22 {
    public static void main(String[] args) {
     int i=0; int num=0;
     for (i=0;i<=10;i++){
         i=num+i;
         System.out.println(i);
     }
    }
}
