import java.util.Scanner;

public class Task11 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("first num");
        int num1=scanner.nextInt();
        System.out.println("second num");
        int num2=scanner.nextInt();
        System.out.println(num1*num2);
}}
