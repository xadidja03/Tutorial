import java.util.Scanner;

public class Task19 {

    public static void main (String[]args){
        Scanner in= new Scanner(System.in);
        int eded=in.nextInt();
        System.out.println("square:"+ eded*eded);
        System.out.println("cube:"+eded*eded*eded);
        System.out.println("ededin 4 cu derecesi:"+Math.pow(eded, 4));
    }
}
