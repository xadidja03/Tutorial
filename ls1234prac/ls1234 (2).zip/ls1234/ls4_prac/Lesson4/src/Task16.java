import java.util.Scanner;

public class Task16 {
    public static void main(String[] Strings) {

        Scanner input = new Scanner(System.in);

        System.out.print("inch daxil edin: ");
        double inch = input.nextDouble();
        double metr = inch * 0.0254;
        System.out.println(inch + " inch  " + metr + " metrdir");
    }
}
