import java.util.Scanner;

public class Task24 {
    public static void main(String[] args){
        Scanner scanner= new Scanner(System.in);
        int eded=scanner.nextInt();
        System.out.println("ededi daxil edin");
        int reqem1=(eded/100)%100;
        int reqem2=(eded/10)%10;
        int reqem3=(eded%10);
        int cem= reqem1+reqem2+reqem3;
        System.out.println("yazdigimiz ededin reqemleri cemi  "+ cem);
    }
}