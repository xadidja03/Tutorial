public class Task6 {
    public static void main(String[] args) {
        String text="hello world";
        String words[]=text.split("\\s");
        int length=words.length;
        int clength=text.length();
        System.out.println(clength);
    }
}
